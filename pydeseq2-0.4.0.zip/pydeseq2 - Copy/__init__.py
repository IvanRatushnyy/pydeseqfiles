from pydeseq2.__version__ import __version__  # noqa
